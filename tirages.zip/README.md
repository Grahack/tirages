# Tirages

Visualisation des issues d’une expérience aléatoire
